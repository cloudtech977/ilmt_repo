Version: LMT-DisconnectedScanner-linux-9.2.30.0-20221213-1111

CIT_Version = 9.2.30.0000
CIT_BuildDate = 2022-12-06

This zip contains CIT binaries for linux platform and configuration files 
to generate inventory package for IBM License Metric Tool 9.2.5 or higher.

For installation and use instruction please refer to:
http://ibm.biz/disconnected_scan_config